package com.example.jordaninventoryapp;

import android.app.IntentService;
import android.content.Intent;
import android.telephony.SmsManager;
import java.util.ArrayList;
import java.util.List;

public class SMSService extends IntentService {
    public SMSService() {
        super("SMSService");
    }

    @Override
    protected void onHandleIntent(Intent intent) {
        if (intent != null) {
            ArrayList<InventoryItem> lowInventoryItems = intent.getParcelableArrayListExtra("lowInventoryItems");
            sendLowInventorySMS(lowInventoryItems);
        }
    }

    private void sendLowInventorySMS(List<InventoryItem> lowInventoryItems) {
        SmsManager smsManager = SmsManager.getDefault();
        String phoneNumber = "YOUR_PHONE_NUMBER"; // Replace with actual phone number
        StringBuilder messageBuilder = new StringBuilder("Low inventory alert:\n");
        for (InventoryItem item : lowInventoryItems) {
            messageBuilder.append(item.getItemName()).append(": ").append(item.getQuantity()).append("\n");
        }
        String message = messageBuilder.toString();
        smsManager.sendTextMessage(phoneNumber, null, message, null, null);
    }
}