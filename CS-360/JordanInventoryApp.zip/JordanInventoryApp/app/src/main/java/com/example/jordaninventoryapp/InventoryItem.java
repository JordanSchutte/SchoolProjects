package com.example.jordaninventoryapp;

import android.os.Parcel;
import android.os.Parcelable;

public class InventoryItem implements Parcelable {
    private int id;
    private String itemName;
    private int quantity;
    public static final int LOW_INVENTORY_THRESHOLD = 5; // Example threshold

    public InventoryItem() {
    }

    public InventoryItem(int id, String itemName, int quantity) {
        this.id = id;
        this.itemName = itemName;
        this.quantity = quantity;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getItemName() {
        return itemName;
    }

    public void setItemName(String itemName) {
        this.itemName = itemName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public boolean isLowInventory() {
        return quantity <= LOW_INVENTORY_THRESHOLD;
    }

    // Parcelable implementation
    protected InventoryItem(Parcel in) {
        id = in.readInt();
        itemName = in.readString();
        quantity = in.readInt();
    }

    public static final Creator<InventoryItem> CREATOR = new Creator<InventoryItem>() {
        @Override
        public InventoryItem createFromParcel(Parcel in) {
            return new InventoryItem(in);
        }

        @Override
        public InventoryItem[] newArray(int size) {
            return new InventoryItem[size];
        }
    };

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(itemName);
        dest.writeInt(quantity);
    }
}