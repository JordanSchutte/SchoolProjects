package com.example.jordaninventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "InventoryDatabase";
    private static final int DATABASE_VERSION = 1;

    // Table names
    private static final String TABLE_USERS = "users";
    private static final String TABLE_INVENTORY = "inventory";

    // Common column names
    private static final String KEY_ID = "id";

    // USER Table column names
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    // INVENTORY Table column names
    private static final String KEY_ITEM_NAME = "itemName";
    private static final String KEY_QUANTITY = "quantity";

    // Create table statements
    private static final String CREATE_USER_TABLE = "CREATE TABLE " + TABLE_USERS +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_USERNAME + " TEXT," +
            KEY_PASSWORD + " TEXT" + ")";

    private static final String CREATE_INVENTORY_TABLE = "CREATE TABLE " + TABLE_INVENTORY +
            "(" + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
            KEY_ITEM_NAME + " TEXT," +
            KEY_QUANTITY + " INTEGER" + ")";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(CREATE_USER_TABLE);
        db.execSQL(CREATE_INVENTORY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // User Table CRUD Operations
    public boolean addUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_USERNAME, username);
        values.put(KEY_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        String[] columns = {KEY_ID};
        String selection = KEY_USERNAME + "=?" + " AND " + KEY_PASSWORD + "=?";
        String[] selectionArgs = {username, password};
        Cursor cursor = db.query(TABLE_USERS, columns, selection, selectionArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        return count > 0;
    }

    public boolean hasLoggedInUser() {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_USERS + " LIMIT 1";
        Cursor cursor = db.rawQuery(query, null);
        boolean hasUser = cursor.getCount() > 0;
        cursor.close();
        return hasUser;
    }

    // Inventory Table CRUD Operations
    public boolean addInventoryItem(String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ITEM_NAME, itemName);
        values.put(KEY_QUANTITY, quantity);
        long result = db.insert(TABLE_INVENTORY, null, values);
        return result != -1;
    }

    public List<InventoryItem> getAllInventoryItems() {
        List<InventoryItem> itemList = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_INVENTORY;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem();
                item.setId(cursor.getInt(0));
                item.setItemName(cursor.getString(1));
                item.setQuantity(cursor.getInt(2));
                itemList.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return itemList;
    }

    public void updateInventoryItem(InventoryItem item) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(KEY_ITEM_NAME, item.getItemName());
        values.put(KEY_QUANTITY, item.getQuantity());
        db.update(TABLE_INVENTORY, values, KEY_ID + "=?", new String[]{String.valueOf(item.getId())});
    }

    public void deleteInventoryItem(int id) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_INVENTORY, KEY_ID + "=?", new String[]{String.valueOf(id)});
    }
    public List<InventoryItem> getLowInventoryItems() {
        List<InventoryItem> lowInventoryItems = new ArrayList<>();
        String selectQuery = "SELECT * FROM " + TABLE_INVENTORY + " WHERE " + KEY_QUANTITY + " <= " + InventoryItem.LOW_INVENTORY_THRESHOLD;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(selectQuery, null);
        if (cursor.moveToFirst()) {
            do {
                InventoryItem item = new InventoryItem();
                item.setId(cursor.getInt(0));
                item.setItemName(cursor.getString(1));
                item.setQuantity(cursor.getInt(2));
                lowInventoryItems.add(item);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return lowInventoryItems;
    }
}