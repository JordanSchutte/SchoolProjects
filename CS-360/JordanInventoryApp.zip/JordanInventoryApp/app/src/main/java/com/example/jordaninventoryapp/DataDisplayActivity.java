package com.example.jordaninventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity implements DataAdapter.OnItemClickListener {
    private DatabaseHelper dbHelper;
    private DataAdapter adapter;
    private List<InventoryItem> inventoryItems;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        dbHelper = new DatabaseHelper(this);
        inventoryItems = dbHelper.getAllInventoryItems();

        RecyclerView recyclerView = findViewById(R.id.data_grid);
        adapter = new DataAdapter(inventoryItems, this);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        Button addButton = findViewById(R.id.add_item_button);
        addButton.setOnClickListener(v -> showAddItemDialog());

        checkLowInventory();
    }

    private void showAddItemDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        final EditText itemNameEditText = dialogView.findViewById(R.id.itemNameEditText);
        final EditText quantityEditText = dialogView.findViewById(R.id.quantityEditText);

        builder.setPositiveButton("Add", (dialog, which) -> {
            String itemName = itemNameEditText.getText().toString().trim();
            String quantityStr = quantityEditText.getText().toString().trim();

            if (!itemName.isEmpty() && !quantityStr.isEmpty()) {
                int quantity = Integer.parseInt(quantityStr);
                if (dbHelper.addInventoryItem(itemName, quantity)) {
                    loadInventoryData();
                    checkLowInventory();
                }
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    @Override
    public void onItemClick(InventoryItem item) {
        // Handle item click if needed
    }

    @Override
    public void onEditClick(InventoryItem item) {
        showEditItemDialog(item);
    }

    @Override
    public void onDeleteClick(InventoryItem item) {
        showDeleteConfirmationDialog(item);
    }

    private void showEditItemDialog(InventoryItem item) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        LayoutInflater inflater = this.getLayoutInflater();
        View dialogView = inflater.inflate(R.layout.dialog_add_item, null);
        builder.setView(dialogView);

        EditText itemNameEditText = dialogView.findViewById(R.id.itemNameEditText);
        EditText quantityEditText = dialogView.findViewById(R.id.quantityEditText);

        itemNameEditText.setText(item.getItemName());
        quantityEditText.setText(String.valueOf(item.getQuantity()));

        builder.setPositiveButton("Update", (dialog, which) -> {
            String itemName = itemNameEditText.getText().toString().trim();
            int quantity = Integer.parseInt(quantityEditText.getText().toString().trim());
            item.setItemName(itemName);
            item.setQuantity(quantity);
            dbHelper.updateInventoryItem(item);
            adapter.notifyDataSetChanged();
            checkLowInventory();
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());

        builder.show();
    }

    private void showDeleteConfirmationDialog(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Item")
                .setMessage("Are you sure you want to delete this item?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    dbHelper.deleteInventoryItem(item.getId());
                    inventoryItems.remove(item);
                    adapter.notifyDataSetChanged();
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void loadInventoryData() {
        inventoryItems.clear();
        inventoryItems.addAll(dbHelper.getAllInventoryItems());
        adapter.notifyDataSetChanged();
    }

    private void checkLowInventory() {
        List<InventoryItem> lowInventoryItems = dbHelper.getLowInventoryItems();
        if (!lowInventoryItems.isEmpty()) {
            Intent intent = new Intent(this, SMSService.class);
            intent.putExtra("lowInventoryItems", new ArrayList<>(lowInventoryItems));
            startService(intent);
        }
    }
}