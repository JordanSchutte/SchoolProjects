package com.example.jordaninventoryapp;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        // Initialize buttons
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnDisplayData = findViewById(R.id.btnDisplayData);
        Button btnSMSPermissions = findViewById(R.id.btnSMSPermissions);

        // Set onClick listeners
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LoginActivity.class));
            }
        });

        btnDisplayData.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if user is logged in before allowing access to inventory data
                if (isLoggedIn()) {
                    startActivity(new Intent(MainActivity.this, DataDisplayActivity.class));
                } else {
                    Toast.makeText(MainActivity.this, "Please log in first", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnSMSPermissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SMSPermissionActivity.class));
            }
        });
    }

    // Method to check if a user is logged in
    private boolean isLoggedIn() {
        // This is a simple check. You might want to implement a more robust session management system
        return dbHelper.hasLoggedInUser();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // You could update UI elements here if needed, based on login state
    }

    // You might want to add an onDestroy method to close the database connection
    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}